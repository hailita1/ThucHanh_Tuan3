﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Form_Bai2_Tuan3_BTDiemTu
{
    class StaticData
    {
        public static List<BaiTapDienTu> baitap = new List<BaiTapDienTu>();
    }
}
