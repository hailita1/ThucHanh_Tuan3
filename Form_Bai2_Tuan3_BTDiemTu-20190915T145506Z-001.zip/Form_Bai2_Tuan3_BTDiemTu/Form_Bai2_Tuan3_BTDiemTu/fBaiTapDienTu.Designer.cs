﻿namespace Form_Bai2_Tuan3_BTDiemTu
{
    partial class fBaiTapDienTu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.điệnTửToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bàiTậpĐiệnTử1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bàiTậpĐiệnTử1ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bàiTậpĐiệnTử1ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.bàiTậpĐiệnTử1ToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.trắcNghiệmGiớiTừToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bài1ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bài2ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bài3ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.biếnĐổiCâuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bài1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bài2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bài3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đặtCâuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bài1ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.bài2ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.bài3ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.LightGray;
            this.menuStrip1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.điệnTửToolStripMenuItem,
            this.trắcNghiệmGiớiTừToolStripMenuItem,
            this.biếnĐổiCâuToolStripMenuItem,
            this.đặtCâuToolStripMenuItem,
            this.thoátToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(454, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // điệnTửToolStripMenuItem
            // 
            this.điệnTửToolStripMenuItem.BackColor = System.Drawing.Color.LightGray;
            this.điệnTửToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bàiTậpĐiệnTử1ToolStripMenuItem,
            this.bàiTậpĐiệnTử1ToolStripMenuItem1,
            this.bàiTậpĐiệnTử1ToolStripMenuItem2,
            this.bàiTậpĐiệnTử1ToolStripMenuItem3});
            this.điệnTửToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.điệnTửToolStripMenuItem.Name = "điệnTửToolStripMenuItem";
            this.điệnTửToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.điệnTửToolStripMenuItem.Text = "&Điền từ";
            // 
            // bàiTậpĐiệnTử1ToolStripMenuItem
            // 
            this.bàiTậpĐiệnTử1ToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.bàiTậpĐiệnTử1ToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bàiTậpĐiệnTử1ToolStripMenuItem.Name = "bàiTậpĐiệnTử1ToolStripMenuItem";
            this.bàiTậpĐiệnTử1ToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.bàiTậpĐiệnTử1ToolStripMenuItem.Text = "Bài tập điền từ 1";
            this.bàiTậpĐiệnTử1ToolStripMenuItem.Click += new System.EventHandler(this.BàiTậpĐiệnTử1ToolStripMenuItem_Click);
            // 
            // bàiTậpĐiệnTử1ToolStripMenuItem1
            // 
            this.bàiTậpĐiệnTử1ToolStripMenuItem1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bàiTậpĐiệnTử1ToolStripMenuItem1.Name = "bàiTậpĐiệnTử1ToolStripMenuItem1";
            this.bàiTậpĐiệnTử1ToolStripMenuItem1.Size = new System.Drawing.Size(170, 22);
            this.bàiTậpĐiệnTử1ToolStripMenuItem1.Text = "Bài tập điền từ 2";
            this.bàiTậpĐiệnTử1ToolStripMenuItem1.Click += new System.EventHandler(this.BàiTậpĐiệnTử1ToolStripMenuItem1_Click);
            // 
            // bàiTậpĐiệnTử1ToolStripMenuItem2
            // 
            this.bàiTậpĐiệnTử1ToolStripMenuItem2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bàiTậpĐiệnTử1ToolStripMenuItem2.Name = "bàiTậpĐiệnTử1ToolStripMenuItem2";
            this.bàiTậpĐiệnTử1ToolStripMenuItem2.Size = new System.Drawing.Size(170, 22);
            this.bàiTậpĐiệnTử1ToolStripMenuItem2.Text = "Bài tập điền từ 3";
            this.bàiTậpĐiệnTử1ToolStripMenuItem2.Click += new System.EventHandler(this.BàiTậpĐiệnTử1ToolStripMenuItem2_Click);
            // 
            // bàiTậpĐiệnTử1ToolStripMenuItem3
            // 
            this.bàiTậpĐiệnTử1ToolStripMenuItem3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bàiTậpĐiệnTử1ToolStripMenuItem3.Name = "bàiTậpĐiệnTử1ToolStripMenuItem3";
            this.bàiTậpĐiệnTử1ToolStripMenuItem3.Size = new System.Drawing.Size(170, 22);
            this.bàiTậpĐiệnTử1ToolStripMenuItem3.Text = "Bài tập điền từ 4";
            this.bàiTậpĐiệnTử1ToolStripMenuItem3.Click += new System.EventHandler(this.BàiTậpĐiệnTử1ToolStripMenuItem3_Click);
            // 
            // trắcNghiệmGiớiTừToolStripMenuItem
            // 
            this.trắcNghiệmGiớiTừToolStripMenuItem.BackColor = System.Drawing.Color.LightGray;
            this.trắcNghiệmGiớiTừToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bài1ToolStripMenuItem1,
            this.bài2ToolStripMenuItem1,
            this.bài3ToolStripMenuItem1});
            this.trắcNghiệmGiớiTừToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trắcNghiệmGiớiTừToolStripMenuItem.Name = "trắcNghiệmGiớiTừToolStripMenuItem";
            this.trắcNghiệmGiớiTừToolStripMenuItem.Size = new System.Drawing.Size(143, 20);
            this.trắcNghiệmGiớiTừToolStripMenuItem.Text = "&Trắc nghiệm giới từ";
            // 
            // bài1ToolStripMenuItem1
            // 
            this.bài1ToolStripMenuItem1.Name = "bài1ToolStripMenuItem1";
            this.bài1ToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.bài1ToolStripMenuItem1.Text = "Bài 1";
            // 
            // bài2ToolStripMenuItem1
            // 
            this.bài2ToolStripMenuItem1.Name = "bài2ToolStripMenuItem1";
            this.bài2ToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.bài2ToolStripMenuItem1.Text = "Bài 2";
            // 
            // bài3ToolStripMenuItem1
            // 
            this.bài3ToolStripMenuItem1.Name = "bài3ToolStripMenuItem1";
            this.bài3ToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.bài3ToolStripMenuItem1.Text = "Bài 3";
            // 
            // biếnĐổiCâuToolStripMenuItem
            // 
            this.biếnĐổiCâuToolStripMenuItem.BackColor = System.Drawing.Color.LightGray;
            this.biếnĐổiCâuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bài1ToolStripMenuItem,
            this.bài2ToolStripMenuItem,
            this.bài3ToolStripMenuItem});
            this.biếnĐổiCâuToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.biếnĐổiCâuToolStripMenuItem.Name = "biếnĐổiCâuToolStripMenuItem";
            this.biếnĐổiCâuToolStripMenuItem.Size = new System.Drawing.Size(97, 20);
            this.biếnĐổiCâuToolStripMenuItem.Text = "&Biến đổi câu";
            // 
            // bài1ToolStripMenuItem
            // 
            this.bài1ToolStripMenuItem.Name = "bài1ToolStripMenuItem";
            this.bài1ToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.bài1ToolStripMenuItem.Text = "Bài 1";
            // 
            // bài2ToolStripMenuItem
            // 
            this.bài2ToolStripMenuItem.Name = "bài2ToolStripMenuItem";
            this.bài2ToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.bài2ToolStripMenuItem.Text = "Bài 2";
            // 
            // bài3ToolStripMenuItem
            // 
            this.bài3ToolStripMenuItem.Name = "bài3ToolStripMenuItem";
            this.bài3ToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.bài3ToolStripMenuItem.Text = "Bài 3";
            // 
            // đặtCâuToolStripMenuItem
            // 
            this.đặtCâuToolStripMenuItem.BackColor = System.Drawing.Color.LightGray;
            this.đặtCâuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bài1ToolStripMenuItem2,
            this.bài2ToolStripMenuItem2,
            this.bài3ToolStripMenuItem2});
            this.đặtCâuToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.đặtCâuToolStripMenuItem.Name = "đặtCâuToolStripMenuItem";
            this.đặtCâuToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.đặtCâuToolStripMenuItem.Text = "Đặt &câu";
            // 
            // bài1ToolStripMenuItem2
            // 
            this.bài1ToolStripMenuItem2.Name = "bài1ToolStripMenuItem2";
            this.bài1ToolStripMenuItem2.Size = new System.Drawing.Size(107, 22);
            this.bài1ToolStripMenuItem2.Text = "Bài 1";
            // 
            // bài2ToolStripMenuItem2
            // 
            this.bài2ToolStripMenuItem2.Name = "bài2ToolStripMenuItem2";
            this.bài2ToolStripMenuItem2.Size = new System.Drawing.Size(107, 22);
            this.bài2ToolStripMenuItem2.Text = "Bài 2";
            // 
            // bài3ToolStripMenuItem2
            // 
            this.bài3ToolStripMenuItem2.Name = "bài3ToolStripMenuItem2";
            this.bài3ToolStripMenuItem2.Size = new System.Drawing.Size(107, 22);
            this.bài3ToolStripMenuItem2.Text = "Bài 3";
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.thoátToolStripMenuItem.Text = "Th&oát";
            this.thoátToolStripMenuItem.Click += new System.EventHandler(this.ThoátToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // fBaiTapDienTu
            // 
            this.Appearance.BackColor = System.Drawing.Color.White;
            this.Appearance.Options.UseBackColor = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 223);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "fBaiTapDienTu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bài tập tiếng anh";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem điệnTửToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bàiTậpĐiệnTử1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bàiTậpĐiệnTử1ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem bàiTậpĐiệnTử1ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem bàiTậpĐiệnTử1ToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem biếnĐổiCâuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trắcNghiệmGiớiTừToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đặtCâuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem bài1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bài2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bài3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bài1ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem bài2ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem bài3ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem bài1ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem bài2ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem bài3ToolStripMenuItem2;
    }
}

